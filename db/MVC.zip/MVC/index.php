<!DOCTYPE HTML>
<html>
	<head>
		<title>Liste des utilisateurs</title>
	</head>
	<body>


<h1>Exemple simple de site en PHP</h1>


<?php
require_once("Model/connexion.php");
require("Model/functions.php");


if(isset($_GET["action"]) && $_GET["action"]=="save") {
	if(isset($_GET["id"]) &&  $_GET["id"]!=null) {
		$reponse = updateusers($db,$_GET["nom"],$_GET["prenom"],$_GET["id"]);
		
	} else {
		$reponse = insertusers($db,$_GET["nom"],$_GET["prenom"]);
		
	}
}


if(isset($_GET["action"]) && ($_GET["action"]=="ajouter" || $_GET["action"]=="modifier")) {
	$nom = "";
	$prenom = "";
	$id = "";
	
	if($_GET["action"]=="modifier") {
		$reponse = editusers($db,$_GET["id"]);

    while($user = $reponse->fetch()){
		$nom = $user["nom"];		
		$prenom = $user["prenom"];		
		$id = $user["id"];
	}
}
	
	include("View/add.php");	
	
} else { 		
	$reponse = showusers($db);
	include("View/list.php");
} ?>	
	</body>
</html>


